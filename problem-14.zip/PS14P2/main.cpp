#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

class Computer {
private:
    string make;
    string model;
    string cpu;
    string ram;
    string hardDrive;
    string type;
    double cost;

public:
    // Constructor with default values
    Computer() {
        make = "Lenovo";
        model = "LE100A";
        cpu = "Intel";
        ram = "32GB";
        hardDrive = "HD";
        type = "Laptop";
        cost = 0.0;
    }

    // Setters
    void setMake(const string& m) { make = (m == "Lenovo" || m == "HP" || m == "Apple") ? m : "Lenovo"; }
    void setModel(const string& m) { model = m.empty() ? "LE100A" : m; }
    void setCPU(const string& c) { cpu = (c == "Intel" || c == "AMD") ? c : "Intel"; }
    void setRAM(const string& r) { ram = (r == "8GB" || r == "16GB" || r == "32GB") ? r : "32GB"; }
    void setHardDrive(const string& h) { hardDrive = (h == "SSD" || h == "HD") ? h : "HD"; }
    void setType(const string& t) {
        if (t == "Laptop" || t == "Notebook" || t == "Tablet" || t == "Desktop")
            type = t;
        else
            type = "Laptop";
    }

    // Compute cost
    void computeCost() {
        cost = 0.0;

        // Make
        if (make == "Lenovo") cost += 1200;
        else if (make == "HP") cost += 1000;
        else if (make == "Apple") cost += 2000;

        // CPU
        if (cpu == "Intel") cost += 200;
        else if (cpu == "AMD") cost += 0;

        // RAM
        if (ram == "16GB") cost += 300;
        else if (ram == "32GB") cost += 500;

        // Hard Drive
        if (hardDrive == "SSD") cost += 500;

        // Type
        if (type == "Laptop") cost += 300;
        else if (type == "Tablet") cost -= 200;
        // Notebook or Desktop no adjustment
    }

    double getCost() const { return cost; }

    void display() const {
        cout << fixed << setprecision(2);
        cout << "Computer Make: " << make << endl;
        cout << "Model: " << model << endl;
        cout << "CPU: " << cpu << endl;
        cout << "RAM: " << ram << endl;
        cout << "Hard Drive: " << hardDrive << endl;
        cout << "Type: " << type << endl;
        cout << "Total Cost: $" << cost << endl;
    }
};

int main() {
    Computer comp;
    string make, model, cpu, ram, hdd, type;

    cout << "Enter computer info (Ctrl+Z to stop):\n";

    while (cin >> make >> model >> cpu >> ram >> hdd >> type) {
        comp.setMake(make);
        comp.setModel(model);
        comp.setCPU(cpu);
        comp.setRAM(ram);
        comp.setHardDrive(hdd);
        comp.setType(type);
        comp.computeCost();

        cout << "\nComputer Details:\n";
        comp.display();
        cout << "\nEnter next computer info: ";
    }

    cout << "\nProgram terminated.\n";
    return 0;
}

#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

class Membership {
private:
    string firstName;
    string lastName;
    int age;
    string membershipType;
    double membershipCost;

public:
    // Constructor with default values
    Membership() {
        firstName = "Not Entered";
        lastName = "Not Entered";
        age = 18;
        membershipType = "Bronze";
        membershipCost = 0.0;
    }

    // Setters and getters
    void setFirstName(const string& fName) { firstName = fName; }
    string getFirstName() const { return firstName; }

    void setLastName(const string& lName) { lastName = lName; }
    string getLastName() const { return lastName; }

    void setAge(int a) { age = a; }
    int getAge() const { return age; }

    void setMembershipType(const string& type) {
        if (type == "Gold" || type == "Silver" || type == "Bronze")
            membershipType = type;
        else
            membershipType = "Bronze";  // default
    }

    string getMembershipType() const { return membershipType; }

    // Compute membership cost
    void computeCost() {
        if (membershipType == "Gold") membershipCost = 1200.0;
        else if (membershipType == "Silver") membershipCost = 1000.0;
        else membershipCost = 500.0;

        if (age > 50)
            membershipCost *= 0.9; // 10% discount
    }

    double getMembershipCost() const { return membershipCost; }

    // Display all info
    void display() const {
        cout << fixed << setprecision(2);
        cout << "Name: " << firstName << " " << lastName << endl;
        cout << "Age: " << age << endl;
        cout << "Membership Type: " << membershipType << endl;
        cout << "Membership Cost: $" << membershipCost << endl;
    }
};

int main() {
    Membership member;
    string fName, lName, type;
    int ageInput;

    cout << "Enter membership information (Ctrl+Z to stop):\n";

    while (cin >> fName >> lName >> ageInput >> type) {
        member.setFirstName(fName);
        member.setLastName(lName);
        member.setAge(ageInput);
        member.setMembershipType(type);
        member.computeCost();

        cout << "\nMembership Details:\n";
        member.display();
        cout << "\nEnter next member info: ";
    }

    cout << "\nProgram terminated.\n";
    return 0;
}

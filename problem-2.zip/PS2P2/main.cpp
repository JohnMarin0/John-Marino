#include <iostream>
#include <string>
using namespace std;

int main() {
    string lastName;
    double hours, payRate, grossPay;

    cout << "Enter last name: ";
    cin >> lastName;
    cout << "Enter hours worked: ";
    cin >> hours;
    cout << "Enter pay rate: ";
    cin >> payRate;

    grossPay = hours * payRate;

    cout << "Last Name: " << lastName << ", Gross Pay: $" << grossPay << endl;

    return 0;
}

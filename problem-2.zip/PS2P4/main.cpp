#include <iostream>
#include <string>
using namespace std;

int main() {
    string lastName;
    int credits;
    double tuition;
    const double creditRate = 250.0;
    const double labFee = 100.0;

    cout << "Enter last name: ";
    cin >> lastName;
    cout << "Enter credits taken: ";
    cin >> credits;

    tuition = (credits * creditRate) + labFee;

    cout << "Last Name: " << lastName << ", Tuition: $" << tuition << endl;

    return 0;
}
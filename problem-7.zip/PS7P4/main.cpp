#include <iostream>
#include <string>
using namespace std;

int main() {
    string lastName;
    char jobCode;
    double hours, rate, pay, sumPay = 0;
    int count = 0;

    cout << "Enter last name, job code, hours (Ctrl+Z to stop): ";
    while (cin >> lastName >> jobCode >> hours) {
        if (jobCode == 'L') rate = 25;
        else if (jobCode == 'A') rate = 30;
        else if (jobCode == 'J') rate = 50;
        else rate = 0;

        if (hours > 40)
            pay = (40 * rate) + (hours - 40) * (rate * 1.5);
        else
            pay = hours * rate;

        sumPay += pay;
        count++;

        cout << "Employee: " << lastName
             << " Code: " << jobCode
             << " Hours: " << hours
             << " Pay: $" << pay << endl;

        cout << "Enter last name, job code, hours (Ctrl+Z to stop): ";
    }
    if (count > 0)
        cout << "Average Pay: $" << sumPay / count
             << " Entries: " << count << endl;
    return 0;
}

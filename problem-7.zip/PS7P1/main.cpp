#include <iostream>
using namespace std;

int main() {
    int quantity;
    double price, extended, discount, discounted, total = 0;

    cout << "Enter quantity and price (Ctrl+Z to stop): ";
    while (cin >> quantity >> price) {
        extended = quantity * price;
        if (quantity > 1000)
            discount = extended * 0.10;
        else
            discount = 0;
        discounted = extended - discount;
        total += discounted;

        cout << "Quantity: " << quantity
             << " Price: $" << price
             << " Extended: $" << extended
             << " Discount: $" << discount
             << " Discounted Price: $" << discounted << endl;

        cout << "Enter quantity and price (Ctrl+Z to stop): ";
    }
    cout << "Total of discounted prices: $" << total << endl;
    return 0;
}

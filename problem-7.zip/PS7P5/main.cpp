#include <iostream>
#include <string>
using namespace std;

int main() {
    string lastName;
    char district;
    int credits, count = 0, totalCredits = 0;
    double tuition, sumTuition = 0;

    cout << "Enter last name, credit hours, district code (Ctrl+Z to stop): ";
    while (cin >> lastName >> credits >> district) {
        if (district == 'I') tuition = credits * 250;
        else if (district == 'O') tuition = credits * 550;
        else tuition = 0;

        sumTuition += tuition;
        totalCredits += credits;
        count++;

        cout << "Student: " << lastName
             << " Tuition Owed: $" << tuition << endl;

        cout << "Enter last name, credit hours, district code (Ctrl+Z to stop): ";
    }
    cout << "Total Tuition: $" << sumTuition
         << " Total Credits: " << totalCredits
         << " Students: " << count << endl;
    return 0;
}

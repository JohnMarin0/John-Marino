#include <iostream>
#include <string>
using namespace std;

int main() {
    string city;
    double miles, gallons, mpg, sumMiles = 0;
    int tripCount = 0;

    cout << "Enter city, miles, gallons (Ctrl+Z to stop): ";
    while (cin >> city >> miles >> gallons) {
        mpg = miles / gallons;
        sumMiles += miles;
        tripCount++;
        cout << "Destination: " << city << " MPG: " << mpg << endl;
        cout << "Enter city, miles, gallons (Ctrl+Z to stop): ";
    }
    cout << "Total miles: " << sumMiles << " Trips made: " << tripCount << endl;
    return 0;
}

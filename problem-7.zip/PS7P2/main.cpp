#include <iostream>
#include <string>
using namespace std;

int main() {
    string lastName;
    int hits, atBats, count = 0;
    double average;

    cout << "Enter last name, hits, and at bats (Ctrl+Z to stop): ";
    while (cin >> lastName >> hits >> atBats) {
        average = static_cast<double>(hits) / atBats;
        count++;
        cout << "Player: " << lastName << " Batting Average: " << average << endl;
        cout << "Enter last name, hits, and at bats (Ctrl+Z to stop): ";
    }
    cout << "Total players entered: " << count << endl;
    return 0;
}

#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    double salary; // Annual salary

public:
    Employee() : name(""), salary(0.0) {}

    Employee(string n, double s) {
        name = n;
        salary = s;
    }

    void setData(string n, double s) {
        name = n;
        salary = s;
    }

    string getName() const { return name; }
    double getSalary() const { return salary; }

    // Base class bonus = 10% of salary
    virtual double bonus() const {
        return salary * 0.10;
    }

    // Display method
    virtual void display() const {
        cout << "Employee Name: " << name << endl;
        cout << "Salary: $" << salary << endl;
        cout << "Bonus (Base): $" << bonus() << endl;
    }
};

#endif

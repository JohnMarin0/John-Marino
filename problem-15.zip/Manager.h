#ifndef MANAGER_H
#define MANAGER_H

#include "Employee.h"

class Manager : public Employee {
public:
    Manager() : Employee() {}

    Manager(string n, double s) : Employee(n, s) {}

    // Long term bonus = 50% of salary
    double Long_Term_Bonus() const {
        return salary * 0.50;
    }

    // Override bonus method = 50% of annual salary
    double bonus() const override {
        return salary * 0.50;
    }

    // Display all information
    void display() const override {
        cout << "Manager Name: " << name << endl;
        cout << "Salary: $" << salary << endl;
        cout << "Annual Bonus (Overridden 50%): $" << bonus() << endl;
        cout << "Long Term Bonus (50%): $" << Long_Term_Bonus() << endl;
    }
};

#endif

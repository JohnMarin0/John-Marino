#include <iostream>
#include "Employee.h"
#include "Manager.h"
using namespace std;

int main() {

    // Load a Manager object with data
    Manager mgr("John Doe", 80000);

    // Show everything works
    cout << "===== Manager Object Test =====" << endl;
    mgr.display();

    cout << "\nCalling individual methods:" << endl;
    cout << "Name: " << mgr.getName() << endl;
    cout << "Salary: $" << mgr.getSalary() << endl;
    cout << "Bonus (overridden): $" << mgr.bonus() << endl;
    cout << "Long Term Bonus: $" << mgr.Long_Term_Bonus() << endl;

    return 0;
}

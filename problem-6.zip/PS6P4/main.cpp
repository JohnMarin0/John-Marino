#include <iostream>
using namespace std;

int main() {
    char equipmentCode, dayCode;
    double cost;

    cout << "Enter equipment code (A/B/C): ";
    cin >> equipmentCode;
    cout << "Enter day code (F/H): ";
    cin >> dayCode;

    if (equipmentCode == 'A') {
        if (dayCode == 'F') cost = 10.0;
        else if (dayCode == 'H') cost = 15.0;
    } else if (equipmentCode == 'B') {
        if (dayCode == 'F') cost = 20.0;
        else if (dayCode == 'H') cost = 35.0;
    } else if (equipmentCode == 'C') {
        if (dayCode == 'F') cost = 45.0;
        else if (dayCode == 'H') cost = 40.0;
    } else {
        cost = 50.0;
    }

    cout << "Rental cost: $" << cost << endl;

    return 0;
}

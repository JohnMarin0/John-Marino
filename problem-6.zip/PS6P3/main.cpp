#include <iostream>
using namespace std;

int main() {
    int tickets;
    char location;
    double price, total;

    cout << "Enter number of tickets: ";
    cin >> tickets;
    cout << "Enter location code (H/L): ";
    cin >> location;

    if (tickets > 25 || location == 'H') price = 30.0;
    else if ((tickets > 10 && tickets <= 24) || location == 'L') price = 40.0;
    else price = 50.0;

    total = tickets * price;

    cout << "Tickets: " << tickets << endl;
    cout << "Price per Ticket: $" << price << endl;
    cout << "Total Cost: $" << total << endl;

    return 0;
}

#include <iostream>
using namespace std;

int main() {
    int partNumber, quantity;
    double costPerUnit, total;

    cout << "Enter part number: ";
    cin >> partNumber;
    cout << "Enter quantity: ";
    cin >> quantity;

    if (partNumber == 10 && quantity > 1000) costPerUnit = 1.0;
    else if (partNumber == 99 && quantity > 500) costPerUnit = 2.0;
    else costPerUnit = 5.0;

    total = quantity * costPerUnit;

    cout << "Part Number: " << partNumber << endl;
    cout << "Cost per Unit: $" << costPerUnit << endl;
    cout << "Total Cost: $" << total << endl;

    return 0;
}

#include <iostream>
using namespace std;

int main() {
    char jobCode;
    int hours;
    double rate, grossPay;

    cout << "Enter job code (L/J/A): ";
    cin >> jobCode;
    cout << "Enter hours worked: ";
    cin >> hours;

    if (jobCode == 'L') {
        if (hours > 40) rate = 50.0;
        else rate = 40.0;
    } else if (jobCode == 'J') {
        if (hours > 60) rate = 100.0;
        else rate = 75.0;
    } else if (jobCode == 'A') {
        if (hours > 40) rate = 25.0;
        else rate = 20.0;
    }

    grossPay = hours * rate;

    cout << "Gross Salary: $" << grossPay << endl;

    return 0;
}

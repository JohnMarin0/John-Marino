#include <iostream>
using namespace std;

int main() {
    double purchasePrice, currentPrice, change;

    cout << "Enter purchase price: ";
    cin >> purchasePrice;
    cout << "Enter current price: ";
    cin >> currentPrice;

    change = ((currentPrice - purchasePrice) / purchasePrice) * 100;

    cout << "Percentage change: " << change << "%" << endl;
    return 0;
}

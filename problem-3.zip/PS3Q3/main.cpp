#include <iostream>
using namespace std;

int main() {
    double mealTotal, tip, totalWithTip;

    cout << "Enter the meal total: ";
    cin >> mealTotal;

    tip = mealTotal * 0.15;
    totalWithTip = mealTotal + tip;

    cout << "Meal Total: $" << mealTotal << endl;
    cout << "Tip (15%): $" << tip << endl;
    cout << "Total with Tip: $" << totalWithTip << endl;

    return 0;
}

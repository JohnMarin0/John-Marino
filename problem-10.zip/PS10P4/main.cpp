#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
using namespace std;

// Function to compute biweekly pay
float computeBiWeekly(float annual_salary) {
    return annual_salary / 26;
}

int main() {
    string data = R"(
Jones 50000.00
Adams 65000.00
Baker 45000.00
Smith 75000.00
)";
    istringstream infile(data);

    string lname;
    float annual_salary, biweekly, total_salary = 0.0f;
    int count = 0;

    cout << fixed << setprecision(2);
    cout << left << setw(12) << "Last Name" << setw(15) << "Annual Salary"
         << setw(15) << "Biweekly Pay" << endl;
    cout << string(42, '-') << endl;

    while (infile >> lname >> annual_salary) {
        biweekly = computeBiWeekly(annual_salary);
        total_salary += annual_salary;
        count++;

        cout << left << setw(12) << lname << setw(15) << annual_salary
             << setw(15) << biweekly << endl;
    }

    float avg_salary = (count > 0) ? total_salary / count : 0;

    cout << "\nTotal Annual Salary: $" << total_salary << endl;
    cout << "Number of Employees: " << count << endl;
    cout << "Average Annual Salary: $" << avg_salary << endl;

    return 0;
}

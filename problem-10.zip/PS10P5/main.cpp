#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
using namespace std;

// Function to compute tuition and course fees
void computeTuition(char code, float credits, float &tuition, float &fees) {
    float cost_per_credit = (code == 'I') ? 250.00f : 500.00f;
    tuition = credits * cost_per_credit;
    fees = tuition * 0.10f;
}

int main() {
    string data = R"(
Jones I 15.00
Baker O 20.00
Davis I 10.00
Michaels O 12.00
Baez I 12.00
)";
    istringstream infile(data);

    string lname;
    char code;
    float credits, tuition, fees;
    float total_tuition = 0.0f;
    int student_count = 0;

    cout << fixed << setprecision(2);
    cout << left << setw(12) << "Last Name"
         << setw(10) << "Code"
         << setw(15) << "Credits"
         << setw(15) << "Tuition"
         << setw(15) << "Course Fees" << endl;
    cout << string(67, '-') << endl;

    while (infile >> lname >> code >> credits) {
        computeTuition(code, credits, tuition, fees);
        total_tuition += tuition;
        student_count++;

        cout << left << setw(12) << lname
             << setw(10) << code
             << setw(15) << credits
             << setw(15) << tuition
             << setw(15) << fees << endl;
    }

    float average_tuition = (student_count > 0) ? total_tuition / student_count : 0;

    cout << "\nTotal Tuition Owed: $" << total_tuition << endl;
    cout << "Number of Students: " << student_count << endl;
    cout << "Average Tuition per Student: $" << average_tuition << endl;

    return 0;
}

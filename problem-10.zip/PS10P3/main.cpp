#include <iostream>
#include <sstream>
#include <iomanip>
using namespace std;

// Function to compute MPG
float computeMPG(float miles, float gallons) {
    return (gallons != 0) ? miles / gallons : 0;
}

int main() {
    string data = R"(
20 500
10 600
5 50
10 350
)";
    istringstream infile(data);

    float miles, gallons, mpg;
    float total_miles = 0.0f, total_gallons = 0.0f;

    cout << fixed << setprecision(2);
    cout << setw(10) << "Gallons" << setw(10) << "Miles" << setw(10) << "MPG" << endl;
    cout << string(30, '-') << endl;

    while (infile >> gallons >> miles) {
        mpg = computeMPG(miles, gallons);
        total_miles += miles;
        total_gallons += gallons;
        cout << setw(10) << gallons << setw(10) << miles << setw(10) << mpg << endl;
    }

    cout << "\nTotal Gallons: " << total_gallons << endl;
    cout << "Total Miles: " << total_miles << endl;

    return 0;
}

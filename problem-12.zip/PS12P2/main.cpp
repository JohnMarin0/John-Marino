#include <iostream>
#include <string>
using namespace std;

const int SIZE = 8;

void readCities(string city[], int pop[]) {
    for (int i = 0; i < SIZE; i++) {
        cin >> city[i] >> pop[i];
    }
}

void displayCities(string city[], int pop[]) {
    cout << "City Population Data:\n";
    for (int i = 0; i < SIZE; i++) {
        cout << city[i] << " " << pop[i] << endl;
    }
}

int searchCity(string city[], string key) {
    for (int i = 0; i < SIZE; i++) {
        if (city[i] == key)
            return i;
    }
    return -1;
}

int main() {
    string city[SIZE];
    int population[SIZE];
    string key;

    cout << "Enter 8 city names and populations:\n";
    readCities(city, population);
    displayCities(city, population);

    cout << "\nEnter city name, ctrl+z to stop: ";
    while (cin >> key) {
        int pos = searchCity(city, key);
        if (pos != -1)
            cout << city[pos] << " has a population of " << population[pos] << endl;
        else
            cout << key << " not found\n";

        cout << "\nEnter city name, ctrl+z to stop: ";
    }

    cout << "Goodbye. Have a nice day.\n";
    return 0;
}

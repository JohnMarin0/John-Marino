#include <iostream>
#include <string>
using namespace std;

const int SIZE = 10;

void readStudents(string first[], string last[], double gpa[]) {
    for (int i = 0; i < SIZE; i++) {
        cin >> first[i] >> last[i] >> gpa[i];
    }
}

void displayStudents(string first[], string last[], double gpa[]) {
    cout << "\nStudent List:\n";
    for (int i = 0; i < SIZE; i++) {
        cout << first[i] << " " << last[i] << " " << gpa[i] << endl;
    }
}

void displayReverse(string first[], string last[], double gpa[]) {
    cout << "\nStudent List (Reverse Order):\n";
    for (int i = SIZE - 1; i >= 0; i--) {
        cout << first[i] << " " << last[i] << " " << gpa[i] << endl;
    }
}

int main() {
    string first[SIZE], last[SIZE];
    double gpa[SIZE];

    cout << "Enter 10 student first name, last name, GPA:\n";
    readStudents(first, last, gpa);
    displayStudents(first, last, gpa);
    displayReverse(first, last, gpa);

    return 0;
}

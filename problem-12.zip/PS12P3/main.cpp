#include <iostream>
#include <string>
using namespace std;

const int SIZE = 10;

void readEmployees(string first[], string last[], double salary[]) {
    for (int i = 0; i < SIZE; i++) {
        cin >> first[i] >> last[i] >> salary[i];
    }
}

void displayEmployees(string first[], string last[], double salary[]) {
    cout << "Employee List:\n";
    for (int i = 0; i < SIZE; i++) {
        cout << first[i] << " " << last[i] << " $" << salary[i] << endl;
    }
}

int searchLastName(string last[], string key) {
    for (int i = 0; i < SIZE; i++) {
        if (last[i] == key)
            return i;
    }
    return -1;
}

int main() {
    string first[SIZE], last[SIZE], key;
    double salary[SIZE];

    cout << "Enter 10 employees (first last salary):\n";
    readEmployees(first, last, salary);
    displayEmployees(first, last, salary);

    cout << "\nEnter last name to search, ctrl+z to stop: ";
    while (cin >> key) {
        int pos = searchLastName(last, key);
        if (pos != -1)
            cout << first[pos] << " " << last[pos] << " earns $" << salary[pos] << endl;
        else
            cout << key << " not found\n";

        cout << "\nEnter last name to search, ctrl+z to stop: ";
    }

    return 0;
}

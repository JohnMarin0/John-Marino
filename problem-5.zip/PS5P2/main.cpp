#include <iostream>
using namespace std;

int main() {
    int lbs;
    double rate, total;

    cout << "Enter quantity of apples (lbs): ";
    cin >> lbs;

    if (lbs > 100)
        rate = 0.10;
    else if (lbs >= 50)
        rate = 0.25;
    else
        rate = 0.50;

    total = lbs * rate;

    cout << "Price per pound: $" << rate << " | Total: $" << total << endl;

    return 0;
}

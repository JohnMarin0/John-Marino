#include <iostream>
#include <string>
using namespace std;

int main() {
    string lastName;
    char jobCode;
    double hours, rate, total;

    cout << "Enter employee last name: ";
    cin >> lastName;
    cout << "Enter hours worked: ";
    cin >> hours;
    cout << "Enter job code (E/J/A): ";
    cin >> jobCode;

    if (jobCode == 'E' || jobCode == 'e')
        rate = 25.00;
    else if (jobCode == 'J' || jobCode == 'j')
        rate = 20.00;
    else if (jobCode == 'A' || jobCode == 'a')
        rate = 15.00;
    else {
        cout << "Invalid job code!" << endl;
        return 1;
    }

    total = hours * rate;

    cout << "Employee: " << lastName << " | Hours: " << hours
         << " | Rate: $" << rate << " | Total Pay: $" << total << endl;

    return 0;
}

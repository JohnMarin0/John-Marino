#include <iostream>
#include <vector>
#include <string>
using namespace std;

// ===== GLOBAL STRUCTURE DEFINITION =====
struct Student {
    string firstName;
    string lastName;
    char districtCode;     // 'I' for in-district, 'O' for out-of-district
    int creditHours;
    double tuitionBalance;
};

// ===== FUNCTION PROTOTYPES =====
double computeTuition(char districtCode, int creditHours);
void displayStudents(const vector<Student>& students);

int main() {
    vector<Student> students;
    Student temp;

    cout << "Enter student first name, last name, district code (I/O), and credit hours.\n";
    cout << "Press Ctrl+Z (Windows) or Ctrl+D (Mac/Linux) to stop.\n\n";

    // Input loop
    while (cin >> temp.firstName >> temp.lastName >> temp.districtCode >> temp.creditHours) {
        // Compute tuition
        temp.tuitionBalance = computeTuition(temp.districtCode, temp.creditHours);

        // Add student to vector
        students.push_back(temp);
    }

    // Display results
    displayStudents(students);

    // Show total count
    cout << "\nTotal number of students: " << students.size() << endl;

    return 0;
}

// ===== FUNCTION DEFINITIONS =====
double computeTuition(char districtCode, int creditHours) {
    double rate;

    if (districtCode == 'I' || districtCode == 'i')
        rate = 250.00;  // In-district rate
    else
        rate = 500.00;  // Out-of-district rate

    return creditHours * rate;
}

void displayStudents(const vector<Student>& students) {
    cout << "\n========== STUDENT TUITION REPORT ==========\n";

    for (const auto& s : students) {
        cout << s.firstName << " " << s.lastName
             << " (" << s.districtCode << ") "
             << s.creditHours << " credit hours, "
             << "Tuition Owed: $" << s.tuitionBalance << endl;
    }
}

#include <iostream>
#include <string>
using namespace std;

double calculatePay(char jobCode, double hours) {
    double rate;
    if (jobCode == 'L') rate = 25;
    else if (jobCode == 'A') rate = 30;
    else if (jobCode == 'J') rate = 50;
    else rate = 0;

    double regularHours = (hours > 40) ? 40 : hours;
    double overtimeHours = (hours > 40) ? hours - 40 : 0;

    return (regularHours * rate) + (overtimeHours * rate * 1.5);
}

int main() {
    string lastName;
    char jobCode;
    double hours;
    double totalPay = 0;
    int employeeCount = 0;

    cout << "Enter last name, job code, and hours worked (Ctrl+Z to stop):\n";
    while (cin >> lastName >> jobCode >> hours) {
        double pay = calculatePay(jobCode, hours);
        cout << "Employee: " << lastName << ", Pay: $" << pay << endl;
        totalPay += pay;
        employeeCount++;
    }

    if (employeeCount > 0) {
        cout << "\nTotal pay: $" << totalPay << endl;
        cout << "Number of employees: " << employeeCount << endl;
        cout << "Average pay: $" << totalPay / employeeCount << endl;
    }

    return 0;
}
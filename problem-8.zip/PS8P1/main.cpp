#include <iostream>
#include <string>
using namespace std;

double calculateMPG(double miles, double gallons) {
    return miles / gallons;
}

int main() {
    string city;
    double miles, gallons;
    double totalMiles = 0;
    int tripCount = 0;

    cout << "Enter destination city, miles traveled, and gallons used (Ctrl+Z to stop):\n";
    while (cin >> ws && getline(cin, city) && cin >> miles >> gallons) {
        double mpg = calculateMPG(miles, gallons);
        cout << "City: " << city << ", MPG: " << mpg << endl;
        totalMiles += miles;
        tripCount++;
    }

    cout << "\nTotal miles traveled: " << totalMiles << endl;
    cout << "Number of trips: " << tripCount << endl;

    return 0;
}

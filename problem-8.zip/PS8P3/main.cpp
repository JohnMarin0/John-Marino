#include <iostream>
#include <string>
using namespace std;

double calculateTuition(int credits) {
    return credits * 250;
}

int main() {
    string lastName;
    int credits;
    double totalTuition = 0;
    int studentCount = 0;

    cout << "Enter student last name and credits taken (Ctrl+Z to stop):\n";
    while (cin >> lastName >> credits) {
        double tuition = calculateTuition(credits);
        cout << "Student: " << lastName << ", Credits: " << credits 
             << ", Tuition: $" << tuition << endl;
        totalTuition += tuition;
        studentCount++;
    }

    cout << "\nTotal tuition: $" << totalTuition << endl;
    cout << "Number of students: " << studentCount << endl;

    return 0;
}

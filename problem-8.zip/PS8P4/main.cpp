#include <iostream>
using namespace std;

double unitPrice(char productCode) {
    if (productCode == 'W') return 10.0;
    if (productCode == 'C') return 15.0;
    if (productCode == 'G') return 20.0;
    return 0;
}

double shipping(char productCode) {
    if (productCode == 'W') return 2.0;
    if (productCode == 'C') return 5.0;
    if (productCode == 'G') return 7.0;
    return 0;
}

int main() {
    char productCode;
    int quantity;
    double totalAll = 0;

    cout << "Enter product code and quantity (Ctrl+Z to stop):\n";
    while (cin >> productCode >> quantity) {
        double price = unitPrice(productCode);
        double ship = shipping(productCode);
        double extended = price * quantity;
        double total = extended + ship;

        cout << "Product: " << productCode
             << ", Unit Price: $" << price
             << ", Shipping: $" << ship
             << ", Extended: $" << extended
             << ", Total: $" << total << endl;

        totalAll += total;
    }

    cout << "\nTotal of all orders: $" << totalAll << endl;

    return 0;
}

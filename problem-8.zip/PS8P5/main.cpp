#include <iostream>
#include <string>
using namespace std;

// Function to determine lab fee based on department and course code
double getLabFee(const string& dept, int course) {
    if (dept == "CIS" && course == 101) return 50.0;
    if (dept == "CIS" && course == 121) return 100.0;
    if (dept == "MAT" && course == 111) return 25.0;
    if (dept == "MAT" && course == 112) return 35.0;
    if (dept == "ENG" && course == 100) return 55.0;
    return 50.0; // All others
}

int main() {
    string department;
    int courseCode;
    double totalLabFees = 0;
    int courseCount = 0;

    cout << "Enter department and course code (Ctrl+Z to stop):\n";

    while (cin >> department >> courseCode) {
        double labFee = getLabFee(department, courseCode);
        cout << "Department: " << department 
             << ", Course Code: " << courseCode 
             << ", Lab Fee: $" << labFee << endl;
        totalLabFees += labFee;
        courseCount++;
    }

    if (courseCount > 0) {
        double avgLabFee = totalLabFees / courseCount;
        cout << "\nTotal lab fees: $" << totalLabFees << endl;
        cout << "Average lab fee: $" << avgLabFee << endl;
    } else {
        cout << "\nNo courses entered.\n";
    }

    return 0;
}

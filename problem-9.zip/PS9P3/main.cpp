#include <iostream>
#include <iomanip>
using namespace std;

double computeMPG(double miles, double gallons) {
    if (gallons == 0) return 0;
    return miles / gallons;
}

double computeCost(double gallons) {
    const double pricePerGallon = 3.50;
    return gallons * pricePerGallon;
}

int main() {
    string city;
    double miles, gallons;
    double totalCost = 0.0;

    cout << fixed << setprecision(2);
    cout << "Enter destination city, miles, and gallons (Ctrl+Z to stop): ";
    while (cin >> city >> miles >> gallons) {
        double mpg = computeMPG(miles, gallons);
        double cost = computeCost(gallons);
        cout << city << " - MPG: " << mpg << ", Gas Cost: $" << cost << endl;
        totalCost += cost;
        cout << "Enter destination city, miles, and gallons (Ctrl+Z to stop): ";
    }

    cout << "\nTotal Gas Cost: $" << totalCost << endl;
    return 0;
}

#include <iostream>
#include <iomanip>
using namespace std;

double getCostPerCredit(char districtCode) {
    if (toupper(districtCode) == 'I')
        return 250.0;
    else
        return 550.0;
}

double computeTuition(double creditHours, double rate) {
    return creditHours * rate;
}

int main() {
    string lastName;
    char districtCode;
    double creditHours, rate, tuition, totalTuition = 0.0;

    cout << fixed << setprecision(2);
    cout << "Enter student last name, credit hours, and district code (Ctrl+Z to stop): ";
    while (cin >> lastName >> creditHours >> districtCode) {
        rate = getCostPerCredit(districtCode);
        tuition = computeTuition(creditHours, rate);
        cout << lastName << " - Tuition Owed: $" << tuition << endl;
        totalTuition += tuition;
        cout << "Enter student last name, credit hours, and district code (Ctrl+Z to stop): ";
    }

    cout << "\nTotal Tuition Owed: $" << totalTuition << endl;
    return 0;
}

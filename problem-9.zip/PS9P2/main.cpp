#include <iostream>
#include <iomanip>
using namespace std;

double computeBattingAverage(double hits, double atBats) {
    if (atBats == 0) return 0;
    return hits / atBats;
}

int main() {
    string lastName;
    double hits, atBats;
    int playerCount = 0;

    cout << fixed << setprecision(3);
    cout << "Enter player's last name, hits, and at-bats (Ctrl+Z to stop): ";
    while (cin >> lastName >> hits >> atBats) {
        double avg = computeBattingAverage(hits, atBats);
        cout << lastName << " - Batting Average: " << avg << endl;
        playerCount++;
        cout << "Enter player's last name, hits, and at-bats (Ctrl+Z to stop): ";
    }

    cout << "\nTotal number of players: " << playerCount << endl;
    return 0;
}

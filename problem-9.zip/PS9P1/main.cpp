#include <iostream>
#include <iomanip>
using namespace std;

double computeTotal(double quantity, double price) {
    return quantity * price;
}

double computeDiscount(double total) {
    double discountRate = (total > 10000.0) ? 0.10 : 0.05;
    double discountAmount = total * discountRate;
    return total - discountAmount;
}

int main() {
    double quantity, price;
    double total, discountTotal;
    double sumTotal = 0.0, sumDiscountTotal = 0.0;

    cout << fixed << setprecision(2);

    cout << "Enter quantity and price (Ctrl+Z to stop): ";
    while (cin >> quantity >> price) {
        total = computeTotal(quantity, price);
        discountTotal = computeDiscount(total);
        cout << "Total: $" << total << "\tDiscounted Total: $" << discountTotal << endl;
        sumTotal += total;
        sumDiscountTotal += discountTotal;
        cout << "Enter quantity and price (Ctrl+Z to stop): ";
    }

    cout << "\nGrand Total: $" << sumTotal;
    cout << "\nGrand Discount Total: $" << sumDiscountTotal << endl;
    return 0;
}

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int numBooks;
    double costPerBook, orderTotal, shipping;

    cout << "Enter number of books: ";
    cin >> numBooks;
    cout << "Enter cost per book: ";
    cin >> costPerBook;

    orderTotal = numBooks * costPerBook;

    if (orderTotal > 50)
        shipping = 0;
    else
        shipping = 25;

    cout << fixed << setprecision(2);
    cout << "Order Total: $" << orderTotal << endl;
    cout << "Shipping Charge: $" << shipping << endl;

    return 0;
}

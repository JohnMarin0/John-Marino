#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
using namespace std;

// Function to compute savings and sales tax
void computeAuto(float msrp, float sales_price, float &savings, float &sales_tax) {
    savings = msrp - sales_price;
    sales_tax = sales_price * 0.07f;
}

int main() {
    // Simulated file data
    string data = R"(
Honda Accord 25000.00 22000.00
Honda CRV 30000.00 28000.00
Toyota Corrola 28000.00 25000.00
Ford Fusion 23000.00 20000.00
)";
    istringstream infile(data);

    string make, model;
    float msrp, sales_price, savings, sales_tax, total_savings = 0.0f;

    cout << fixed << setprecision(2);
    cout << left << setw(10) << "Make" << setw(12) << "Model"
         << setw(10) << "MSRP" << setw(15) << "SalesPrice"
         << setw(10) << "Savings" << setw(10) << "SalesTax" << endl;
    cout << string(67, '-') << endl;

    while (infile >> make >> model >> msrp >> sales_price) {
        computeAuto(msrp, sales_price, savings, sales_tax);
        total_savings += savings;

        cout << left << setw(10) << make << setw(12) << model
             << setw(10) << msrp << setw(15) << sales_price
             << setw(10) << savings << setw(10) << sales_tax << endl;
    }

    cout << "\nTotal Savings: $" << total_savings << endl;
    return 0;
}

#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
using namespace std;

// Function to compute extended price
float computeExtendedPrice(int quantity, float price) {
    return quantity * price;
}

int main() {
    string data = R"(
Banana 10 0.50
Oranges 5 0.10
Cookies 15 0.30
Hamburgers 4 1.00
Buns 4 0.50
Soda 10 0.99
)";
    istringstream infile(data);

    string item;
    int quantity;
    float price, extended_price, total_extended = 0.0f;

    cout << fixed << setprecision(2);
    cout << left << setw(12) << "Item" << setw(10) << "Qty"
         << setw(15) << "Cost/Item" << setw(15) << "Ext.Price" << endl;
    cout << string(52, '-') << endl;

    while (infile >> item >> quantity >> price) {
        extended_price = computeExtendedPrice(quantity, price);
        total_extended += extended_price;

        cout << left << setw(12) << item << setw(10) << quantity
             << setw(15) << price << setw(15) << extended_price << endl;
    }

    float tax = total_extended * 0.07f;
    float total = total_extended + tax;

    cout << "\nSum of Extended Prices: $" << total_extended << endl;
    cout << "Tax (7%): $" << tax << endl;
    cout << "Total Receipt: $" << total << endl;

    return 0;
}

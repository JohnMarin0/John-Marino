#include <iostream>
using namespace std;

int main() {
    double num1, num2, sum, product, difference;

    cout << "Enter two real numbers: ";
    cin >> num1 >> num2;

    sum = num1 + num2;
    product = num1 * num2;
    difference = num1 - num2;

    cout << "The sum is: " << sum << endl;
    cout << "The product is: " << product << endl;
    cout << "The difference is: " << difference << endl;

    return 0;
}

#include <iostream>
using namespace std;

int main() {
    double num1, num2, sum;

    cout << "Enter two real numbers: ";
    cin >> num1 >> num2;

    sum = num1 + num2;

    cout << "The sum is: " << sum << endl;

    return 0;
}
